﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace cezar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        char[] alf= new char[]{'а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы','ь','э','ю','я'};
        char[]  ALF= new char[] { 'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й', 'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф', 'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Ъ', 'Ы', 'Ь', 'Э', 'Ю', 'Я' };
        
        private void button1_Click(object sender, EventArgs e)
        {
            int k;
            string n="";
            string sh= "";
            int flag = 0;
            if (key.Text != "")
            {
                k = Convert.ToInt32(key.Text);
                
                if (norm.Text != "")
                {
                    int j;
                    n = norm.Text;
                    for (int i = 0; i < n.Length; i++)
                    {
                        j = 33;
                        for (int f = 0; f < alf.Length; f++)
                        {
                            
                            if ((n[i]) == alf[f]) j = f;
                            
                        }
                        if (j != 33)
                        {
                            if (j + k > 32)
                            {
                                j = j + k - 33;
                            }
                            else j += k;
                            sh += alf[j];                            
                        }
                        else
                        {
                            for (int f = 0; f < ALF.Length; f++)
                            {
                                if ((n[i]) == ALF[f])  j = f;   
                            }
                            if (j != 33)
                            {
                                if (j + k > 32)
                                {
                                    j = j + k - 33;
                                }
                                else j += k;
                                sh += ALF[j];                                
                            }

                            else
                            {
                                sh += n[i];                            
                            }
                        }
                    }
                    flag = 1;
                    shifr.Text = sh;
                }
                if (shifr.Text != "" && flag == 0)
                {
                    int j;
                    sh = shifr.Text;
                    for (int i = 0; i < sh.Length; i++)
                    {
                        j = 33;
                        for (int f = 0; f < alf.Length; f++)
                        {

                            if ((sh[i]) == alf[f]) j = f;

                        }
                        if (j != 33)
                        {
                            if (j - k < 0)
                            {
                                j = 33+(j-k);
                            }
                            else j -= k;
                            n += alf[j];
                        }
                        else
                        {
                            for (int f = 0; f < ALF.Length; f++)
                            {
                                if ((sh[i]) == ALF[f]) j = f;
                            }
                            if (j != 33)
                            {
                                if (j - k < 0)
                                {
                                    j = 33 + (j - k);
                                }
                                else j += k;
                                n += ALF[j];
                            }

                            else
                            {
                                n += sh[i];
                            }
                        }
                    }
                    
                    norm.Text = n;
                }
                if (norm.Text == "" && shifr.Text == "")
                {
                    MessageBox.Show("Заполните поле 'Текст' или 'Шифр'");
                }
            }
            else
            {
                MessageBox.Show("Введите ключ");
            }
        }
    }
}
